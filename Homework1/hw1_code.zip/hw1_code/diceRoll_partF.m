function [ result ] = diceRoll_partF()
%DICEROLL_PARTF Summary of this function goes here
%   Detailed explanation goes here

result = floor(rand(1)*6) + 1;

end

