imageData = im2double(rgb2gray(imread('zebra_small.jpg')));

prob4function(imageData);
