
imname = 'zebra_small.jpg';
imageData = im2double(rgb2gray(imread(imname)));
prob2function(imageData)